cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/E_Wb.7.1.simple9e.dat                         E_Wb.7.1.simple9e.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.10.eliasfanopart.dat            E_Wb.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.11.optpfd.dat                   E_Wb.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.13.varint.dat                   E_Wb.13.varint.dat 

cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/6.scripts.vbytelzma/E_Wb.6.vbyte.lzma.dat                          E_Wb.6.vbyte.lzma.dat                                                                                                                             
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.22.scripts.RepairGonzalo/E_Wb.4.2.repairG.dat 				    E_Wb.4.2.repairG.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.33.scripts.Repair.skipping.Gonzalo/E_Wb.4.3.repairG.skipping.dat E_Wb.4.3.repairG.skipping.dat 
                                                                                                                            
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/E_Wb.1.4.rice.dat                          E_Wb.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/E_Wb.2.1.vbyte.dat                   E_Wb.2.1.vbyte.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/E_Wb.9.qmx.dat                                   E_Wb.9.qmx.dat 





cp ../../../../../self-indexes/collectResults/wcsa/N.Wb_swcsa.dat       N.Wb_swcsa.dat
cp ../../../../../self-indexes/collectResults/lz77/lz77.f1001_100k      lz77.dat
cp ../../../../../self-indexes/collectResults/lzend/lzend.f1001_100k    lzend.dat
cp ../../../../../self-indexes/collectResults/slp/slp.f1001_100k        slp.dat
cp ../../../../../self-indexes/collectResults/wslp/wslp.f1001_100k      wslp.dat
cp ../../../../../self-indexes/collectResults/rlcsa/Wb_rlcsa			rlcsa.dat
