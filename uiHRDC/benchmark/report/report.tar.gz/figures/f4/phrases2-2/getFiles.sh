cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/N_p2.7.1.simple9e.dat                         N_p2.7.1.simple9e.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.10.eliasfanopart.dat            N_p2.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.11.optpfd.dat                   N_p2.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.13.varint.dat                   N_p2.13.varint.dat 

cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/6.scripts.vbytelzma/N_p2.6.vbyte.lzma.dat                          N_p2.6.vbyte.lzma.dat                                                                                                                             
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.22.scripts.RepairGonzalo/N_p2.4.2.repairG.dat 				    N_p2.4.2.repairG.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.33.scripts.Repair.skipping.Gonzalo/N_p2.4.3.repairG.skipping.dat N_p2.4.3.repairG.skipping.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.33.1.scripts.RepairSkipping.Moffat/N_p2.4.3.1repairG.skipping.moffat.dat  N_p2.4.3.1repairG.skipping.moffat.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.33.2.scripts.RepairSkipping.Sanders/N_p2.4.3.2repairG.skipping.lookup.dat N_p2.4.3.2repairG.skipping.sanders.dat  

                                                                                                                            
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/N_p2.1.4.rice.dat                          N_p2.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/N_p2.2.1.vbyte.dat                   N_p2.2.1.vbyte.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/N_p2.9.qmx.dat                                   N_p2.9.qmx.dat 





cp ../../../../../self-indexes/collectResults/wcsa/N.P2_swcsa.dat       N.P2_swcsa.dat
cp ../../../../../self-indexes/collectResults/lz77/lz77.2_2             lz77.dat
cp ../../../../../self-indexes/collectResults/lzend/lzend.2_2           lzend.dat
cp ../../../../../self-indexes/collectResults/slp/slp.2_2               slp.dat
cp ../../../../../self-indexes/collectResults/wslp/wslp.2_2             wslp.dat
cp ../../../../../self-indexes/collectResults/rlcsa/P2_rlcsa			rlcsa.dat
