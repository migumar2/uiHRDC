cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/E_Wa.7.1.simple9e.dat                         E_Wa.7.1.simple9e.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.10.eliasfanopart.dat            E_Wa.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.11.optpfd.dat                   E_Wa.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.13.varint.dat                   E_Wa.13.varint.dat 

cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/6.scripts.vbytelzma/E_Wa.6.vbyte.lzma.dat                          E_Wa.6.vbyte.lzma.dat                                                                                                                             
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.22.scripts.RepairGonzalo/E_Wa.4.2.repairG.dat 				    E_Wa.4.2.repairG.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/4.33.scripts.Repair.skipping.Gonzalo/E_Wa.4.3.repairG.skipping.dat E_Wa.4.3.repairG.skipping.dat 
                                                                                                                            
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/E_Wa.1.4.rice.dat                          E_Wa.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/E_Wa.2.1.vbyte.dat                   E_Wa.2.1.vbyte.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/E_Wa.9.qmx.dat                                   E_Wa.9.qmx.dat 


cp ../../../../../self-indexes/collectResults/wcsa/N.Wa_swcsa.dat       N.Wa_swcsa.dat
cp ../../../../../self-indexes/collectResults/lz77/lz77.f1_1000         lz77.dat
cp ../../../../../self-indexes/collectResults/lzend/lzend.f1_1000       lzend.dat
cp ../../../../../self-indexes/collectResults/slp/slp.f1_1000           slp.dat
cp ../../../../../self-indexes/collectResults/wslp/wslp.f1_1000         wslp.dat
cp ../../../../../self-indexes/collectResults/rlcsa/Wa_rlcsa			rlcsa.dat






