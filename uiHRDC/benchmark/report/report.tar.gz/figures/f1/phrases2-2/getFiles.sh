
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/N_p2.1.4.rice.dat                         N_p2.1.4.rice.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/N_p2.2.1.vbyte.dat                        N_p2.2.1.vbyte.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/N_p2.2.vbyte.moffat.dat               N_p2.2.vbyte.moffat.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/3.scripts.vbytebitmapSanders/N_p2.3.vbyte.sanders.dat             N_p2.3.vbyte.sanders.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/N_p2.1.4.rice.bitmap8.dat                 N_p2.1.4.rice.bitmap8.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/N_p2.2.vbyte.moffat.bitmap8.dat       N_p2.2.vbyte.moffat.bitmap8.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/N_p2.2.1.vbyte.bitmap8.dat                N_p2.2.1.vbyte.bitmap8.dat 

cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/3.scripts.vbytebitmapSanders/N_p2.3.vbyte.sanders.bitmap8.dat     N_p2.3.vbyte.sanders.bitmap8.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/7.scripts.simple9/N_p2.7.simple9.dat                              N_p2.7.simple9.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/8.scripts.pfordelta/N_p2.8.pfordelta.dat                          N_p2.8.pfordelta.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/9.scripts.qmx.bis/N_p2.9.qmx.dat                                  N_p2.9.qmx.dat

cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.10.eliasfanopart.dat     N_p2.10.eliasfanopart.dat
cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.11.optpfd.dat            N_p2.11.optpfd.dat
cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.12.interpolative.dat     N_p2.12.interpolative.dat
cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.13.varint.dat            N_p2.13.varint.dat

