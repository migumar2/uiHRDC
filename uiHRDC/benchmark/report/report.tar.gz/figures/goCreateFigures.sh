
echo "ENTERING FIGURES DIRECTORY----------"

# see ../goReport.sh
echo $SSIZE
echo $SSIZEPOS

cd f1; bash goAll.sh; cd ..
cd f2; bash goAll.sh; cd ..
cd f3; bash goAll.sh; cd ..
cd f4; bash goAll.sh; cd ..
cd f5; bash goAll.sh; cd ..



echo "EXITTING FIGURES DIRECTORY----------"

