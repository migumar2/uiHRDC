
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/E_Wb.1.4.rice.dat                         E_Wb.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/E_Wb.2.1.vbyte.dat                  E_Wb.2.1.vbyte.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/E_Wb.7.1.simple9e.dat                        E_Wb.7.1.simple9e.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/E_Wb.9.qmx.dat                                      E_Wb.9.qmx.dat 

cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.10.eliasfanopart.dat           E_Wb.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.11.optpfd.dat                  E_Wb.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.12.interpolative.dat           E_Wb.12.interpolative.dat 
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wb.13.varint.dat                  E_Wb.13.varint.dat 




