
cd words1-1000   ; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..
cd words1001-100k; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..
cd phrases2-2    ; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..
cd phrases5-5    ; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..
