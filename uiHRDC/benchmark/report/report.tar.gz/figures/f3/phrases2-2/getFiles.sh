
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/N_p2.1.4.rice.dat                         N_p2.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/N_p2.2.1.vbyte.dat                  N_p2.2.1.vbyte.dat 

cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.scripts.vbytebitmapmoffat/N_p2.2.vbyte.moffat.dat              N_p2.2.vbyte.moffat.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/3.scripts.vbytebitmapSanders/N_p2.vbyte.sanders.dat              N_p2.vbyte.sanders.dat

cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/N_p2.7.1.simple9e.dat                        N_p2.7.1.simple9e.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/N_p2.9.qmx.dat                                  N_p2.9.qmx.dat 

cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.10.eliasfanopart.dat           N_p2.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.11.optpfd.dat                  N_p2.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.12.interpolative.dat           N_p2.12.interpolative.dat 
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/N_p2.13.varint.dat                  N_p2.13.varint.dat 
