
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/1.4.scripts.rice.bitmap/E_Wa.1.4.rice.dat                         E_Wa.1.4.rice.dat  
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/E_Wa.2.1.vbyte.dat                  E_Wa.2.1.vbyte.dat 
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/7.1.scripts.simple9e/E_Wa.7.1.simple9e.dat                        E_Wa.7.1.simple9e.dat
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/9.scripts.qmx.bis/E_Wa.9.qmx.dat                                      E_Wa.9.qmx.dat 

cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.10.eliasfanopart.dat           E_Wa.10.eliasfanopart.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.11.optpfd.dat                  E_Wa.11.optpfd.dat
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.12.interpolative.dat           E_Wa.12.interpolative.dat 
cp ../../../../../indexes/POS/EliasFano.OV14/partitioned_elias_fano/partitioned.EF.pos/E_Wa.13.varint.dat                  E_Wa.13.varint.dat 




