
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/E_Wa.1.4.rice.dat                         E_Wa.1.4.rice.dat 
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/E_Wa.2.1.vbyte.dat                        E_Wa.2.1.vbyte.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/E_Wa.2.vbyte.moffat.dat               E_Wa.2.vbyte.moffat.bitmap1.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/3.scripts.vbytebitmapSanders/E_Wa.3.vbyte.sanders.dat             E_Wa.3.vbyte.sanders.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/E_Wa.1.4.rice.bitmap8.dat                 E_Wa.1.4.rice.bitmap8.dat 
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/E_Wa.2.vbyte.moffat.dat               E_Wa.2.vbyte.moffat.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/E_Wa.2.1.vbyte.dat                        E_Wa.2.1.vbyte.bitmap8.dat 

  

cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/7.scripts.simple9/E_Wa.7.simple9.dat                              E_Wa.7.simple9.dat

cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/E_Wa.10.eliasfanopart.dat     E_Wa.10.eliasfanopart.dat
cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/E_Wa.11.optpfd.dat            E_Wa.11.optpfd.dat


cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.5.scritps.riceRLE/E_Wa.1.5.riceRLE.dat                     E_Wa.1.5.riceRLE.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/6.scripts.vbytelzma/E_Wa.6.vbyte.lzma.dat                    E_Wa.6.vbyte.lzma.dat 
    
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/555.scripts.lzend.delta_sample/E_Wa.5.lzend.dat              E_Wa.5.lzend.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.22.scripts.RepairGonzalo/E_Wa.4.2.repairG.dat              E_Wa.4.2.repairG.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.RepairSkippingGonzalo/E_Wa.4.3.repairG.skipping.dat     E_Wa.4.3.repairG.skipping.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.1.RepairSkippingMoffatGonzalo/E_Wa.4.3.1repairG.skipping.moffat.dat    E_Wa.4.3.1repairG.skipping.moffat.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.2.RepairSkippingSandersGonzalo/E_Wa.4.3.2repairG.skipping.sanders.dat  E_Wa.4.3.2repairG.skipping.sanders.dat

