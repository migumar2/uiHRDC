#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/N_p2.1.4.rice.dat                         N_p2.1.4.rice.dat 
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/N_p2.2.1.vbyte.dat                        N_p2.2.1.vbyte.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/N_p2.2.vbyte.moffat.dat               N_p2.2.vbyte.moffat.bitmap1.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/3.scripts.vbytebitmapSanders/N_p2.3.vbyte.sanders.dat             N_p2.3.vbyte.sanders.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.4.scripts.rice.bitmap/N_p2.1.4.rice.bitmap8.dat                 N_p2.1.4.rice.bitmap8.dat 
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.scripts.vbytebitmapmoffat/N_p2.2.vbyte.moffat.dat               N_p2.2.vbyte.moffat.dat
#cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/2.1.scripts.vbytebitmap/N_p2.2.1.vbyte.dat                        N_p2.2.1.vbyte.bitmap8.dat 

  

cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/7.scripts.simple9/N_p2.7.simple9.dat                              N_p2.7.simple9.dat

cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.10.eliasfanopart.dat     N_p2.10.eliasfanopart.dat
cp ../../../../../indexes/NOPOS/EliasFano.OV14/partitioned_elias_fano/partitioned_elias_fano.nopos/N_p2.11.optpfd.dat            N_p2.11.optpfd.dat


cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/1.5.scritps.riceRLE/N_p2.1.5.riceRLE.dat                     N_p2.1.5.riceRLE.dat
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/6.scripts.vbytelzma/N_p2.6.vbyte.lzma.dat                    N_p2.6.vbyte.lzma.dat 
    
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/555.scripts.lzend.delta_sample/N_p2.5.lzend.dat              N_p2.5.lzend.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.22.scripts.RepairGonzalo/N_p2.4.2.repairG.dat              N_p2.4.2.repairG.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.RepairSkippingGonzalo/N_p2.4.3.repairG.skipping.dat     N_p2.4.3.repairG.skipping.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.1.RepairSkippingMoffatGonzalo/N_p2.4.3.1repairG.skipping.moffat.dat    N_p2.4.3.1repairG.skipping.moffat.dat 
cp ../../../../../indexes/NOPOS/EXPERIMENTS/experiments.20g/4.33.2.RepairSkippingSandersGonzalo/N_p2.4.3.2repairG.skipping.sanders.dat  N_p2.4.3.2repairG.skipping.sanders.dat

