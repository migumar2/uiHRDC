cd length80    ; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..
cd length13000 ; bash getFiles.sh; sed s/2087767849/$SSIZEPOS/ locate.gp > locate2.gp; gnuplot locate2.gp  ; cd ..


