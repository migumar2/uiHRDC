#cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/m.80chars_ii_repairT.dat   m.iip.repairT.dat 
#
#cp ../../../../../self-indexes/WCSA/scripts.swcsa3.is/e.Words20_swcsa.dat                                         e.Words20_swcsa.dat 
#
#cp ../../../../../self-indexes/LZ/scripts/evaluation/results/lz77.snippets80                                      lz77.dat
#cp ../../../../../self-indexes/LZ/scripts/evaluation/results/lzend.snippets80                                     lzend.dat
#cp ../../../../../self-indexes/SLP/scripts/evaluation/results/slp.snippets80                                      slp.dat
#cp ../../../../../self-indexes/SLP/scripts/evaluation/results/wslp.snippets80                                     wslp.dat
#
###FALTA RLCSA



cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/m.80chars_ii_repairT.dat   m.iip.repairT.dat

cp ../../../../../self-indexes/collectResults/wcsa/e.Words20_swcsa.dat     e.Words20_swcsa.dat

cp ../../../../../self-indexes/collectResults/lz77/lz77.snippets80         lz77.dat
cp ../../../../../self-indexes/collectResults/lzend/lzend.snippets80       lzend.dat
cp ../../../../../self-indexes/collectResults/slp/slp.snippets80           slp.dat
cp ../../../../../self-indexes/collectResults/wslp/wslp.snippets80         wslp.dat

cp ../../../../../self-indexes/collectResults/rlcsa/e80_rlcsa			   rlcsa.dat
