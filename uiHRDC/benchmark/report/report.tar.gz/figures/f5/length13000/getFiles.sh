
cp ../../../../../indexes/POS/EXPERIMENTS/experiments.is/2.1.scripts.vbyte.TestExtract/m.13000chars_ii_repairT.dat   m.iip.repairT.dat

cp ../../../../../self-indexes/collectResults/wcsa/e.Words3000_swcsa.dat      e.Words3000_swcsa.dat

cp ../../../../../self-indexes/collectResults/lz77/lz77.snippets13000         lz77.dat
cp ../../../../../self-indexes/collectResults/lzend/lzend.snippets13000       lzend.dat
cp ../../../../../self-indexes/collectResults/slp/slp.snippets13000           slp.dat
cp ../../../../../self-indexes/collectResults/wslp/wslp.snippets13000         wslp.dat

cp ../../../../../self-indexes/collectResults/rlcsa/e13000_rlcsa			  rlcsa.dat
