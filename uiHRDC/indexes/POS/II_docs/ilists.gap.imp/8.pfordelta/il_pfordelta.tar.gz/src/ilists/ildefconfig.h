#ifndef DEFVALUES_INCLUDED
#define DEFVALUES_INCLUDED

// Extensions of created  files

#define POSTINGS "il.pfd"
#define DEFAULT_PFD_THRESHOLD 100

#endif
