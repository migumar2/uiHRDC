Versión en C de la implementación en C++ de Jinru/Suel.

: http://code.google.com/p/poly-ir-toolkit/source/browse/trunk#trunk/src/compression_toolkit
