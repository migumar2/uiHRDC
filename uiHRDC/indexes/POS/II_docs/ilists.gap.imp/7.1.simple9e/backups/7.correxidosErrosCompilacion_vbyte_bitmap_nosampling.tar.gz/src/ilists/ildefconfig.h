#ifndef DEFVALUES_INCLUDED
#define DEFVALUES_INCLUDED

// Extensions of created  files

#define POSTINGS "il.vbyte.nosample"
#define DEFAULT_LEN_BITMAP_DIV 8  // Using a bitmap instead of bytecodes if
								  // lenlist[i] > NumDocIDS / DEFAULT_LEN_BITMAP_DIV
#endif
