/* 
LzmaTest.c
Test application for LZMA Decoder

This file written and distributed to public domain by Igor Pavlov.
This file is part of LZMA SDK 4.26 (2005-08-05)
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "LzmaDecode.h"

const char *kCantReadMessage = "Can not read input file";
const char *kCantWriteMessage = "Can not write output file";
const char *kCantAllocateMessage = "Can not allocate memory";

size_t MyReadFile(FILE *file, void *data, size_t size)
{ 
  if (size == 0)
    return 0;
  return fread(data, 1, size, file); 
}

int MyReadFileAndCheck(FILE *file, void *data, size_t size)
  { return (MyReadFile(file, data, size) == size);} 

size_t MyWriteFile(FILE *file, const void *data, size_t size)
{ 
  if (size == 0)
    return 0;
  return fwrite(data, 1, size, file); 
}

int MyWriteFileAndCheck(FILE *file, const void *data, size_t size)
  { return (MyWriteFile(file, data, size) == size); }


int PrintError(char *buffer, const char *message)
{
  sprintf(buffer + strlen(buffer), "\nError: ");
  sprintf(buffer + strlen(buffer), message);
  return 1;
}


unsigned long getfileSize (char *filename){
	FILE *fpText;
	unsigned long fsize;
	fpText = fopen(filename,"rb");
	fsize=0;
	if (fpText) {
		fseek(fpText,0,2);
		fsize= ftell(fpText);
		fclose(fpText);
	}
	return fsize;
}

SizeT getHeaderSize(){
	return (SizeT)(LZMA_PROPERTIES_SIZE + 8);
}












/** Decodes the LZMAdata in the "inputBuffer" and writes it into outFile) */
int main3(unsigned char *inputBuffer, uint inFileSize, FILE *outFile, char *rs)
{
  /* We use two 32-bit integers to construct 64-bit integer for file size.
     You can remove outSizeHigh, if you don't need >= 4GB supporting,
     or you can use UInt64 outSize, if your compiler supports 64-bit integers*/
  UInt32 outSize = 0;

  SizeT compressedSize;
  unsigned char *inStream;

  SizeT outSizeFull;
  unsigned char *outStream;
  
  CLzmaDecoderState state;  /* it's about 24-80 bytes structure, if int is 32-bit */
  unsigned char properties[LZMA_PROPERTIES_SIZE];

  int res;

	/* fari: computes COMPRESSED SIZE (includes the dictionary and the compressed data)*/
  compressedSize = inFileSize - getHeaderSize();  /*  fari <<-- !! length -13 ! */;

  inStream = inputBuffer;


	fprintf(stderr,"\n FARI::header will contain 5+8bytes (properties + uncompressedSize)");
	fprintf(stderr,"\n \tFARI:: COMPRESSED SIZE = %d bytes (infile - (lzmaprperties = %d + 8))", compressedSize,LZMA_PROPERTIES_SIZE);

  /* Read LZMA properties for compressed stream */

	fprintf(stderr,"\n \tFARI:: Reading properties:: sizeof(properties) = %d bytes (tipically 5bytes)", sizeof(properties));

	memcpy((void*) properties, (const void *) inputBuffer, sizeof(properties));
	inStream += (sizeof(properties));


  /* Read uncompressed size */
  {  	
  	/*Aquí sólo carga outsize y outSizeHigh, a partir de 2 uints 32!!!  = 8bytes */	
    int i;
    for (i = 0; i < 8; i++)
    {
      unsigned char b;
    /*  if (!MyReadFileAndCheck(inFile, &b, 1))
        return PrintError(rs, kCantReadMessage);
	*/
		b= *inStream++;
	
		fprintf(stderr,"\n \t\tFARI:: leído==> \"b\" = %d ",  b);
    
      if (i < 4)
        outSize += (UInt32)(b) << (i * 8);
        /* NO QUEREMOS USAR OUTSIZEHIGH, PERO EN LA CABECERA VENÍA ==> SKIP 4 BYTES */
		/* else
			outSizeHigh += (UInt32)(b) << ((i - 4) * 8);
		*/
    }
    outSizeFull = (SizeT)outSize;    
                
   fprintf(stderr,"\n\tFARI::outSize = %d bytes ", outSize);
   
  }

  /* Decode LZMA properties and allocate memory */
    
  if (LzmaDecodeProperties(&state.Properties, properties, LZMA_PROPERTIES_SIZE) != LZMA_RESULT_OK)
    return PrintError(rs, "Incorrect stream properties");
  state.Probs = (CProb *)malloc(LzmaGetNumProbs(&state.Properties) * sizeof(CProb));

  if (outSizeFull == 0)
    outStream = 0;
  else
    outStream = (unsigned char *)malloc(outSizeFull);


  /** some unnecesary checks in this version */
  if (state.Probs == 0    /* EN ESTE CASO, ABORTA LA DESCOMPRESIÓN !! */
    	|| (outStream == 0 && outSizeFull != 0)
	)
  {
    free(state.Probs);
    free(outStream);
    return PrintError(rs, kCantAllocateMessage);
  }

  /* Decompress */

  { SizeT inProcessed;
    SizeT outProcessed;
    res = LzmaDecode(&state,
      inStream, compressedSize, &inProcessed,
      outStream, outSizeFull, &outProcessed);
      
    if (res != 0)
    {
      sprintf(rs + strlen(rs), "\nDecoding error = %d\n", res);
      res = 1;
    }
    else if (outFile != 0)
    {
      if (!MyWriteFileAndCheck(outFile, outStream, (size_t)outProcessed))
      {
        PrintError(rs, kCantWriteMessage);
        res = 1;
      }
    }
  }

  free(state.Probs);
  free(outStream);

  return res;
}

int main2(int numArgs, const char *args[], char *rs)
{
  FILE *inFile = 0;
  uint inFileSize; 
  unsigned char *inBuffer;

  FILE *outFile = 0;
  int res;

  sprintf(rs + strlen(rs), "\nLZMA Decoder 4.26 Copyright (c) 1999-2005 Igor Pavlov  2005-08-05, modified by Antonio Fariña (2009-09-09)\n");
  if (numArgs < 2 || numArgs > 3)
  {
    sprintf(rs + strlen(rs), "\nUsage:  lzmadecFARI file.lzma [outFile]\n");
    return 1;
  }
  
  inFileSize = (uint) getfileSize((char *) args[1]);
  inBuffer = (unsigned char *) malloc (inFileSize * sizeof(unsigned char)); 
    
  inFile = fopen(args[1], "rb");
  if (inFile == 0)
    return PrintError(rs, "Can not open input file");
	
  /* loads the compressed file. */
	/*fread(inBuffer,sizeof(unsigned char), inFileSize, inFile); */
	if (!MyReadFileAndCheck(inFile, inBuffer, inFileSize))
	return PrintError(rs, kCantReadMessage);

  if (numArgs > 2)
  {
    outFile = fopen(args[2], "wb+");
    if (outFile == 0)
      return PrintError(rs, "Can not open output file");
  }

  res = main3(inBuffer,inFileSize, outFile, rs);

  free(inBuffer);

  if (outFile != 0)
    fclose(outFile);
  fclose(inFile);
  return res;
}

int main(int numArgs, const char *args[])
{
  char rs[800] = { 0 };
  int res = main2(numArgs, args, rs);
  printf(rs);
  return res;
}
