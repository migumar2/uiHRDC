// BranchMisc.h

#ifndef __COMPRESS_BRANCH_MISC_H
#define __COMPRESS_BRANCH_MISC_H

#include "BranchCoder.h"

MyClassA(BC_ARM,   0x05, 1)
MyClassA(BC_ARMT,  0x07, 1)
MyClassA(BC_PPC,   0x02, 5)
MyClassA(BC_SPARC, 0x08, 5)
MyClassA(BC_IA64,  0x04, 1)

#endif
