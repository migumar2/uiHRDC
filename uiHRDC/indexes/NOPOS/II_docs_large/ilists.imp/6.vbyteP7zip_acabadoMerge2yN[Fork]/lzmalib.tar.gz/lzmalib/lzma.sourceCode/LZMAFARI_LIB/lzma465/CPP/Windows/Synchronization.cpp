// Windows/Synchronization.cpp

#include "StdAfx.h"

#include "Synchronization.h"

namespace NWindows {
namespace NSynchronization {

}}
