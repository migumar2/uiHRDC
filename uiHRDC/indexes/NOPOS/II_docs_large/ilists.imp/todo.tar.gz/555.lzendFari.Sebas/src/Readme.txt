---------------------------------------------------------------------------------------
-- Indexación de listas que finalmente están comprimidas con BYTECODES.


En general, todos las técnicas de indexación siguen la misma idea, y un **interfaz común**, con funciones para build_il, 
extract_il (la descomprime por completo), size_il...

Dentro de cada subdirectorio (con estas 2 versiones) te encontrarás un directorio "src" que contendrá la implementacón del interfaz de las invertedLists.


Un saludo,
FAri

