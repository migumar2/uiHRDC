cd lzmalib/lzma.sourceCode
sh compile.sh
