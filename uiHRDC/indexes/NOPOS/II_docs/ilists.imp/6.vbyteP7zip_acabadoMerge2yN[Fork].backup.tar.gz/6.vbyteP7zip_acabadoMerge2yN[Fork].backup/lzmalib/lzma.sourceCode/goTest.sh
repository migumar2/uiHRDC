./farilzmaTest CR.TXT cr.unc ./lzmaEncoder
