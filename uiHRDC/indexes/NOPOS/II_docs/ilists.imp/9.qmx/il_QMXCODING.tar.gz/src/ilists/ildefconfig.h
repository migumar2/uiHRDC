#ifndef DEFVALUES_INCLUDED
#define DEFVALUES_INCLUDED

// Extensions of created  files

#define POSTINGS "il.qmx"
#define DEFAULT_PFD_THRESHOLD 1

#endif
