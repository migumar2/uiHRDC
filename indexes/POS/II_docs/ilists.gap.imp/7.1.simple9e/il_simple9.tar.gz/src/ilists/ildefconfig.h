#ifndef DEFVALUES_INCLUDED
#define DEFVALUES_INCLUDED

// Extensions of created  files

#define POSTINGS "il.simple9"

#endif
