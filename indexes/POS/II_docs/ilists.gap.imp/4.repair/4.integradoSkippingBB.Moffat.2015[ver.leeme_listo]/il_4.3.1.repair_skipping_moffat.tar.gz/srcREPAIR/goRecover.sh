./search_re ../FTB8 8 R 1 1 
